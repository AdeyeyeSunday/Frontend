// src/services/authService.ts
import axios from 'axios';

const apiClient = axios.create({
    baseURL: process.env.API_URL+'/api',
    withCredentials: true,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
});

export default {
    logout() {
        return apiClient.post('/logout');
    },
    login(data: any) {
        return apiClient.post('/login', data)
    },
    createPost(data: any) {
        return apiClient.post('/create-post', data)
    },
    createComment(data: any) {
        return apiClient.post('/create-comment', data)
    },
    getPosts() {
        return apiClient.post('/get-posts')
    },
    getMyPosts() {
        return apiClient.post('/get-my-posts')
    },
    getComment() {
        return apiClient.post('/get-posts')
    },
    getPostByPostId(id:any) {
        return apiClient.post('/get-post-by-id', id)
    },
    getMyPostByUserId(user_id:any) {
        return apiClient.post('/get-user-post', user_id)
    }

};
