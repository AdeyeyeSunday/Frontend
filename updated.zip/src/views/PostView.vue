<template>
  <form @submit.prevent="submit">
    <div class="mb-3">
      <input v-model="formData.postTitle" type="text" class="form-control" placeholder="Post Title">
    </div>
    <div class="mb-3">
      <textarea v-model="formData.postContent" class="form-control" rows="3" placeholder="Post content"></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
  <hr>
  <h3>Posts</h3>
  <table class="table">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Post Title</th>
        <th scope="col">Post Content</th>
        <th scope="col">Timestamp</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="(post, index) in posts" :key="post.id">
        <th scope="row">{{ index + 1 }}</th>
        <td>{{ post.postTitle }}</td>
        <td>{{ post.postContent.substring(0, 50) }}...</td>
        <td>{{ post.timestamp }}</td>
        <td>
          <button @click="viewPost(post)" class="btn btn-info btn-sm me-2">View</button>
          <button @click="deletePost(post.id)" class="btn btn-danger btn-sm">Delete</button>
        </td>
      </tr>
    </tbody>
  </table>

  <!-- View Post Modal -->
  <div class="modal fade" id="viewPostModal" tabindex="-1" aria-labelledby="viewPostModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="viewPostModalLabel">{{ selectedPost.postTitle }}</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p>{{ selectedPost.postContent }}</p>
          <small>Posted on: {{ selectedPost.timestamp }}</small>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, reactive, ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import authService from '@/services/authService';

interface Post {
  id: number;
  postTitle: string;
  postContent: string;
  timestamp: string;
}

interface FormData {
  postTitle: string;
  postContent: string;
}

export default defineComponent({
  name: "PostView",
  setup() {
    const formData = reactive<FormData>({
      postTitle: '',
      postContent: ''
    });

    const posts = ref<Post[]>([]);
    const selectedPost = ref<Post>({} as Post);
    const router = useRouter();
    let viewModal: any;

    const submit = async () => {
      try {
        await authService.createPost(JSON.stringify(formData));
        formData.postTitle = '';
        formData.postContent = '';
        await fetchPosts();
      } catch (e) {
        console.error('Failed to createPost:', e);
      }
    }

    const fetchPosts = async () => {
      try {
        const response = await authService.getPosts();
        posts.value = await response.json();
      } catch (e) {
        console.error('Failed to fetch posts:', e);
      }
    };

    const deletePost = async (postId: number) => {
      try {
        await authService.deletePost(postId);
        await fetchPosts();
      } catch (e) {
        console.error('Failed to delete post:', e);
      }
    };

    const viewPost = (post: Post) => {
      selectedPost.value = post;
      viewModal.show();
    };

    onMounted(() => {
      fetchPosts();
      // We'll initialize the modal in onMounted
      import('bootstrap').then(bootstrap => {
        viewModal = new bootstrap.Modal(document.getElementById('viewPostModal'));
      });
    });

    return {
      formData,
      posts,
      selectedPost,
      submit,
      deletePost,
      viewPost
    }
  }
})
</script>